====== HOW TO INSTALL NARAK BOT ======

== WINDOWS ==
STEP 1:
Install Python 3.6 or Conda Python Version 3.6 ONLY
-- Install Conda Environment 3.6
   1: Install Conda From https://docs.conda.io/en/latest/miniconda.html
   2: Open Command Prompt
   3: Create Conda Environment by using this command "conda create --name venvname python=3.6"
   4: When conda asks if you want to proceed, type "y" and press Enter.
   5: Activate the environment by using this command "conda activate snakes"
