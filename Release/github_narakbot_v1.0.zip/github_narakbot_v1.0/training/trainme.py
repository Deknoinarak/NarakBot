import os
while True:
    os.system('python trainbot.py')